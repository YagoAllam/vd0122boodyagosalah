interface smartPhoneInterface{
    charge: number;
    numberCallsDone:number;

    recharge(x:number):void;
    oneCallDone(min:number):void;
    mychargeNow404():number;
    getNumberCalls():number;
    setNumberCallsZero():void;

}

///////////////////////////////////////////////////////////////////////////////////


class FirstUser implements smartPhoneInterface{
    
    public charge:number;
    public numberCallsDone:number;

    constructor(recharge:number, numberCallsDone:number){
        this.charge = recharge;
        this.numberCallsDone = numberCallsDone;
    }

    public recharge(x:number):void{
        this.charge = this.charge + x;
        
    }

    public oneCallDone(min:number):void{

         this.charge - (0.20 * min);
         this.numberCallsDone =+ 1;

    }

    public mychargeNow404():number{

        return this.charge;

    }

    public getNumberCalls():number{

        return this.numberCallsDone;
    }

    public setNumberCallsZero():void{

        this.numberCallsDone = 0;
        
    }   
}


/////////////////////////////////////////////////////////////////////////

class SecondUser implements smartPhoneInterface{
    
    public charge:number;
    public numberCallsDone:number;

    constructor(recharge:number, numberCallsDone:number){
        this.charge = recharge;
        this.numberCallsDone = numberCallsDone;
    }

    public recharge(x:number):void{
        this.charge = this.charge + x;
        
    }

    public oneCallDone(min:number):void{

         this.charge - (0.20 * min);
         this.numberCallsDone =+ 1;

    }

    public mychargeNow404():number{

        return this.charge;

    }

    public getNumberCalls():number{

        return this.numberCallsDone;
    }

    public setNumberCallsZero():void{

        this.numberCallsDone = 0;
        
    }   

}

////////////////////////////////////////////////////////////////////////////////////////

class ThirdUser implements smartPhoneInterface{
    
    public charge:number;
    public numberCallsDone:number;

    constructor(recharge:number, numberCallsDone:number){
        this.charge = recharge;
        this.numberCallsDone = numberCallsDone;
    }

    public recharge(x:number):void{
        this.charge = this.charge + x;
        
    }

    public oneCallDone(min:number):void{

         this.charge - (0.20 * min);
         this.numberCallsDone =+ 1;

    }

    public mychargeNow404():number{

        return this.charge;

    }

    public getNumberCalls():number{

        return this.numberCallsDone;
    }

    public setNumberCallsZero():void{

        this.numberCallsDone = 0;
        
    }   

}