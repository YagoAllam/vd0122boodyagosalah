"use strict";
///////////////////////////////////////////////////////////////////////////////////
class FirstUser {
    constructor(recharge, numberCallsDone) {
        this.charge = recharge;
        this.numberCallsDone = numberCallsDone;
    }
    recharge(x) {
        this.charge = this.charge + x;
    }
    oneCallDone(min) {
        this.charge - (0.20 * min);
        this.numberCallsDone = +1;
    }
    mychargeNow404() {
        return this.charge;
    }
    getNumberCalls() {
        return this.numberCallsDone;
    }
    setNumberCallsZero() {
        this.numberCallsDone = 0;
    }
}
/////////////////////////////////////////////////////////////////////////
class SecondUser {
    constructor(recharge, numberCallsDone) {
        this.charge = recharge;
        this.numberCallsDone = numberCallsDone;
    }
    recharge(x) {
        this.charge = this.charge + x;
    }
    oneCallDone(min) {
        this.charge - (0.20 * min);
        this.numberCallsDone = +1;
    }
    mychargeNow404() {
        return this.charge;
    }
    getNumberCalls() {
        return this.numberCallsDone;
    }
    setNumberCallsZero() {
        this.numberCallsDone = 0;
    }
}
////////////////////////////////////////////////////////////////////////////////////////
class ThirdUser {
    constructor(recharge, numberCallsDone) {
        this.charge = recharge;
        this.numberCallsDone = numberCallsDone;
    }
    recharge(x) {
        this.charge = this.charge + x;
    }
    oneCallDone(min) {
        this.charge - (0.20 * min);
        this.numberCallsDone = +1;
    }
    mychargeNow404() {
        return this.charge;
    }
    getNumberCalls() {
        return this.numberCallsDone;
    }
    setNumberCallsZero() {
        this.numberCallsDone = 0;
    }
}
